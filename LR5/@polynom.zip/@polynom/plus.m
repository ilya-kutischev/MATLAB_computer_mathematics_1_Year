function r = plus(p,q)
% POLYNOM/PLUS Implement p + q for polynoms.
