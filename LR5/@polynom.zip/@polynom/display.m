function display(p)
% POLYNOM/DISPLAY Command window display of a polynom
