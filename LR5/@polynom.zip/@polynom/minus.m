function r = minus(p,q)
% POLYNOM/MINUS Implement p - q for polynoms.
