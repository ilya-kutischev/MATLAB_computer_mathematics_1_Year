function s = char(p)
% POLYNOM/CHAR
% CHAR(p) is the string representation of p.c
