function r = mtimes(p,q)
% POLYNOM/MTIMES Implement p * q for polynoms.
