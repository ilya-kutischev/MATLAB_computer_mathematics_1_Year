function b = subsref(a,s)
% SUBSREF
