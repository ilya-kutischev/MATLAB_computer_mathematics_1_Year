function plot(p)
% POLYNOM/PLOT PLOT(p) plots the polynom p.
