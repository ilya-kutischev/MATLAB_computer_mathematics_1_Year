function q = int(p,c)
% POLYNOM/INT INT(p,c) calculates the indefinite integral of the polynom p with the coefficient c.